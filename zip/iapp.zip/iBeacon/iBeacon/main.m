//
//  main.m
//  iBeacon
//
//  Created by Chi-Hung Ma on 6/30/13.
//  Copyright (c) 2013 RedBearLab. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RBLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RBLAppDelegate class]));
    }
}
