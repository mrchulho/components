//
//  RBLAppDelegate.h
//  iBeacon
//
//  Copyright (c) 2013 RedBearLab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RBLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
