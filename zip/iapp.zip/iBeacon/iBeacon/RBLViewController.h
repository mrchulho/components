//
//  RBLViewController.h
//  iBeacon
//
//  Copyright (c) 2013 RedBearLab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RBLViewController : UIViewController

@end
